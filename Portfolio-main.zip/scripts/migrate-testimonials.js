/**
 * Testimonial Migration & Privacy Scrub Script
 * 
 * Safety Rules:
 * 1. Default mode is DRY RUN (simulates changes, modifies nothing).
 * 2. NEVER marks public-form submissions (source == "public-form") as approved.
 * 3. Shows public-form submissions in a distinct dedicated section.
 * 4. Removes legacy email fields from all documents to ensure privacy compliance.
 * 5. Optional flag --delete-public-submissions allows deleting public submissions
 *    only after an explicit terminal confirmation prompt.
 * 
 * Usage:
 *   Dry Run (Default):           node scripts/migrate-testimonials.js --dry-run
 *   Execute:                     node scripts/migrate-testimonials.js --execute
 *   Delete Public Submissions:   node scripts/migrate-testimonials.js --delete-public-submissions
 */

import fs from "node:fs";
import path from "node:path";
import readline from "node:readline";
import { fileURLToPath, pathToFileURL } from "node:url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const rootDir = path.resolve(__dirname, "..");

// Helper to load env variables from Frontend/.env or .env.local
function loadEnvFile(filePath) {
  if (!fs.existsSync(filePath)) return;
  const content = fs.readFileSync(filePath, "utf-8");
  for (const line of content.split("\n")) {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith("#")) continue;
    const eqIdx = trimmed.indexOf("=");
    if (eqIdx > 0) {
      const key = trimmed.slice(0, eqIdx).trim();
      const val = trimmed.slice(eqIdx + 1).trim().replace(/^['"]|['"]$/g, "");
      if (!process.env[key]) {
        process.env[key] = val;
      }
    }
  }
}

// Load env files
loadEnvFile(path.join(rootDir, "Frontend", ".env.local"));
loadEnvFile(path.join(rootDir, "Frontend", ".env"));
loadEnvFile(path.join(rootDir, ".env"));

const isDeletePublic = process.argv.includes("--delete-public-submissions");
const isExecute = process.argv.includes("--execute") && !isDeletePublic;
const isDryRun = !isExecute && !isDeletePublic;

const projectId =
  process.env.SANITY_PROJECT_ID ||
  process.env.VITE_SANITY_PROJECT_ID ||
  "n2y8hmqi";

const dataset =
  process.env.SANITY_DATASET ||
  process.env.VITE_SANITY_DATASET ||
  "production";

const token = process.env.SANITY_WRITE_TOKEN;

console.log("==================================================");
console.log("  Sanity Testimonials Migration & Privacy Scrub");
console.log("==================================================");
console.log(`Mode:      ${isDeletePublic ? "DELETE PUBLIC SUBMISSIONS" : isExecute ? "EXECUTE (Live updates)" : "DRY RUN (Simulation only)"}`);
console.log(`Project:   ${projectId}`);
console.log(`Dataset:   ${dataset}`);
console.log("--------------------------------------------------");

// Resolve Sanity client module
let createClient;
try {
  const sanityClientPath = path.join(rootDir, "Frontend", "node_modules", "@sanity", "client", "dist", "index.js");
  const mod = await import(pathToFileURL(sanityClientPath).href);
  createClient = mod.createClient;
} catch {
  const mod = await import("@sanity/client");
  createClient = mod.createClient;
}

if (!token) {
  console.log("\n⚠️ Note: SANITY_WRITE_TOKEN is not currently set in your environment.");
  console.log("Running in read-only public inspection mode...");
}

const client = createClient({
  projectId,
  dataset,
  apiVersion: "2024-05-01",
  token: token || undefined,
  useCdn: false,
  perspective: "raw", // Include drafts and published docs
});

function askQuestion(query) {
  const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout,
  });
  return new Promise((resolve) =>
    rl.question(query, (ans) => {
      rl.close();
      resolve(ans.trim());
    })
  );
}

async function runMigration() {
  try {
    console.log("Fetching all testimonial documents from Sanity (including drafts)...");
    const docs = await client.fetch(
      `*[_type == "testimonial"]{ _id, clientName, clientRole, approved, email, source, submittedAt }`
    );

    console.log(`Found ${docs.length} total testimonial document(s) in dataset "${dataset}".\n`);

    if (docs.length === 0) {
      console.log("ℹ️ No testimonial documents exist in Sanity.");
      return;
    }

    const studioDocs = [];
    const publicDocs = [];

    for (const doc of docs) {
      if (doc.source === "public-form") {
        publicDocs.push(doc);
      } else {
        studioDocs.push(doc);
      }
    }

    // 1. Display Studio Testimonials
    console.log("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
    console.log(`📁 1. Studio Testimonials (${studioDocs.length} found):`);
    console.log("   (These are safe to approve and retain; email fields will be scrubbed)");
    console.log("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");

    for (const doc of studioDocs) {
      const isDraft = doc._id.startsWith("drafts.");
      console.log(`• ID:      ${doc._id}`);
      console.log(`  Name:    ${doc.clientName || "Unnamed"} (${doc.clientRole || "No role"})`);
      console.log(`  Status:  ${isDraft ? "Draft" : "Published"} | approved: ${doc.approved ?? "undefined"}`);
      if (doc.email) {
        console.log(`  Privacy: 🔒 Legacy email "${doc.email}" will be removed`);
      }
      console.log("");
    }

    // 2. Display Public Form Submissions Separately
    console.log("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
    console.log(`📬 2. Public Form Submissions (${publicDocs.length} found):`);
    console.log("   ⚠️ SAFETY POLICY: These will NEVER be automatically approved.");
    console.log("   They must be reviewed and published individually in Sanity Studio.");
    console.log("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");

    for (const doc of publicDocs) {
      const isDraft = doc._id.startsWith("drafts.");
      console.log(`• ID:        ${doc._id}`);
      console.log(`  Name:      ${doc.clientName || "Unnamed"} (${doc.clientRole || "No role"})`);
      console.log(`  Status:    ${isDraft ? "Draft (Unpublished)" : "Published"} | approved: ${doc.approved ?? "undefined"}`);
      console.log(`  Submitted: ${doc.submittedAt || "Unknown date"}`);
      if (doc.email) {
        console.log(`  Privacy:   🔒 Legacy email "${doc.email}" will be removed`);
      }
      console.log("");
    }

    // 3. Handle deletion mode if requested
    if (isDeletePublic) {
      if (!token) {
        console.error("❌ Error: SANITY_WRITE_TOKEN is required to delete documents.");
        process.exit(1);
      }

      if (publicDocs.length === 0) {
        console.log("No public-form submissions found to delete.");
        return;
      }

      console.log("--------------------------------------------------");
      console.log(`⚠️  ATTENTION: You requested to DELETE all ${publicDocs.length} public-form submission(s).`);
      console.log("This action is permanent and cannot be undone.");
      const answer = await askQuestion("Type 'delete' to confirm deletion (anything else cancels): ");

      if (answer.toLowerCase() !== "delete") {
        console.log("❌ Deletion cancelled by user.");
        return;
      }

      console.log("\nDeleting public submissions...");
      for (const doc of publicDocs) {
        await client.delete(doc._id);
        console.log(`  ✓ Deleted: ${doc._id} (${doc.clientName})`);
      }
      console.log("\n✅ Deletion complete.");
      return;
    }

    // 4. Dry Run Summary
    if (isDryRun) {
      const studioNeedsApproval = studioDocs.filter((d) => d.approved !== true).length;
      const totalEmailsToScrub = docs.filter((d) => Boolean(d.email)).length;

      console.log("--------------------------------------------------");
      console.log(`🔍 DRY RUN SUMMARY:`);
      console.log(`- Studio testimonials to mark approved: ${studioNeedsApproval}`);
      console.log(`- Public-form submissions marked approved: 0 (PROTECTED - Never auto-approved)`);
      console.log(`- Legacy email fields to scrub:          ${totalEmailsToScrub}`);
      console.log(`- Data modified:                         0 (Dry run only)`);
      console.log(`\nTo execute these updates live:`);
      if (!token) {
        console.log(`  1. Set SANITY_WRITE_TOKEN in Frontend/.env.local or shell:`);
        console.log(`     $env:SANITY_WRITE_TOKEN="your_write_token"`);
      }
      console.log(`  2. Run: npm run migrate:testimonials`);
      console.log(`\nTo delete all public-form submissions:`);
      console.log(`  Run: node scripts/migrate-testimonials.js --delete-public-submissions`);
      console.log("==================================================");
      return;
    }

    // 5. Execute Live Migration Updates
    if (!token) {
      console.error("\n❌ Error: Cannot execute live updates without SANITY_WRITE_TOKEN.");
      process.exit(1);
    }

    console.log("--------------------------------------------------");
    console.log("🚀 EXECUTING SAFE UPDATES...");

    let updatedCount = 0;

    // Process Studio documents: mark approved and scrub email
    for (const doc of studioDocs) {
      let patch = client.patch(doc._id);
      let hasChanges = false;

      if (doc.approved !== true) {
        patch = patch.set({ approved: true });
        hasChanges = true;
      }

      if (doc.email) {
        patch = patch.unset(["email"]);
        hasChanges = true;
      }

      if (hasChanges) {
        await patch.commit();
        console.log(`  ✓ Updated Studio testimonial: ${doc._id}`);
        updatedCount++;
      }
    }

    // Process Public documents: NEVER mark approved, ONLY scrub email
    for (const doc of publicDocs) {
      if (doc.email) {
        await client.patch(doc._id).unset(["email"]).commit();
        console.log(`  ✓ Scrubbed legacy email from public submission: ${doc._id}`);
        updatedCount++;
      }
    }

    console.log(`\n✅ Migration completed. Updated ${updatedCount} document(s).`);
    console.log("Public submissions remain unapproved drafts for Studio moderation.");
    console.log("==================================================");
  } catch (err) {
    console.error("\n❌ Migration failed:", err.message);
    process.exit(1);
  }
}

runMigration();
